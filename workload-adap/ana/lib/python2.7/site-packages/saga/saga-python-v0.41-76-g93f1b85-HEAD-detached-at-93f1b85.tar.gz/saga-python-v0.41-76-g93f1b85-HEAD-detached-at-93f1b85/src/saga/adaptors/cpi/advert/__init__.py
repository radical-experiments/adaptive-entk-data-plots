
__author__    = "Andre Merzky"
__copyright__ = "Copyright 2013, The SAGA Project"
__license__   = "MIT"


from saga.adaptors.cpi.advert.entry      import Entry
from saga.adaptors.cpi.advert.directory  import Directory


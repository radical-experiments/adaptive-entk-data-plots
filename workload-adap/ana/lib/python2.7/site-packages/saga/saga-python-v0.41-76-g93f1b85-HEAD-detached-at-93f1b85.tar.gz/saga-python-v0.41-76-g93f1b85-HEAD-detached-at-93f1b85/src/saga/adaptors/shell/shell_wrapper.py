
__author__    = "Andre Merzky"
__copyright__ = "Copyright 2013, The SAGA Project"
__license__   = "MIT"


import os

# --------------------------------------------------------------------
# server side job management script
_WRAPPER_SCRIPT = open (os.path.dirname(__file__) + '/shell_wrapper.sh').read ()

